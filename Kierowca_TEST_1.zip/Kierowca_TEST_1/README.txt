KIEROWCA TEST 1
Otwórz index.html w Chrome na Androidzie i zezwól na lokalizację. START TRASY -> jedź -> wybierz czynność -> ZAKOŃCZ TRASĘ. Dane są zapisywane lokalnie. To wersja przeglądarkowa; śledzenie przy wygaszonym ekranie nie jest gwarantowane.
